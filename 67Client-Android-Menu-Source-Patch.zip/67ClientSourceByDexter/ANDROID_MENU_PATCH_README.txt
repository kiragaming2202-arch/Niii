67Client Android-safe ClickGUI patch

Changed:
- src/main/java/dev/sixseven/gui/ClickGuiScreen.java
- Replaced NanoVG-driven ClickGUI rendering with Minecraft DrawContext rendering.
- Added category tabs, module search, and tap-to-toggle module rows.

Important:
- This is a patched SOURCE project, not a built JAR.
- Build was attempted with ./gradlew build but could not download Gradle 9.5.1 because services.gradle.org was unreachable in the build environment.
- Build and runtime validation are still required before using it in Minecraft.
