package dev.sixseven.gui;

import dev.sixseven.SixSevenClient;
import dev.sixseven.gui.config.ConfigPanel;
import dev.sixseven.gui.picker.BlockGridModel;
import dev.sixseven.gui.picker.IconListGridModel;
import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.module.ModuleManager;
import dev.sixseven.module.impl.BlockEspModule;
import dev.sixseven.render.BlurHook;
import dev.sixseven.settings.BlockListSetting;
import dev.sixseven.settings.IconListSetting;
import dev.sixseven.theme.ThemeManager;
import dev.sixseven.util.UiSounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/**
 * Android-safe ClickGUI. This screen deliberately uses Minecraft's DrawContext
 * rather than NanoVG, whose bundled native library is not available on Android.
 */
public class ClickGuiScreen extends Screen {
   private final ConfigPanel configPanel = new ConfigPanel();
   private final List<Module> visibleModules = new ArrayList<>();
   private Screen parent;
   private Category selectedCategory = Category.COMBAT;
   private String search = "";
   private boolean searchFocused;
   private int scroll;
   private static final int LEFT = 18;
   private static final int TOP = 32;
   private static final int SIDEBAR_W = 105;
   private static final int ROW_H = 22;
   private static final int CONTENT_X = LEFT + SIDEBAR_W + 10;
   private static final int CONTENT_W = 270;

   public ClickGuiScreen() { this(null); }

   public ClickGuiScreen(Screen parent) {
      super(Text.literal("67Client"));
      this.parent = parent;
      refreshModules();
   }

   public void onDisplayed() {
      super.onDisplayed();
      UiSounds.guiOpen();
   }

   public boolean shouldPause() { return false; }

   public void close() {
      if (this.client != null) this.client.setScreen(this.parent);
   }

   @Override
   public void removed() {
      BlurHook.clear();
      SixSevenClient.config().save();
   }

   private void refreshModules() {
      visibleModules.clear();
      ModuleManager manager = SixSevenClient.modules();
      if (manager == null) return;
      for (Module module : manager.inCategory(selectedCategory)) {
         if (search.isBlank()
               || module.getName().toLowerCase().contains(search.toLowerCase())
               || module.getDescription().toLowerCase().contains(search.toLowerCase())) {
            visibleModules.add(module);
         }
      }
      int maxScroll = Math.max(0, visibleModules.size() - 1);
      scroll = Math.max(0, Math.min(scroll, maxScroll));
   }

   @Override
   public void render(DrawContext g, int mouseX, int mouseY, float delta) {
      g.fill(0, 0, width, height, 0xB8000000);
      int panelRight = Math.min(width - 12, CONTENT_X + CONTENT_W);
      int panelBottom = height - 18;
      g.fill(LEFT, TOP, panelRight, panelBottom, 0xF0181B24);
      g.fill(LEFT, TOP, panelRight, TOP + 28, 0xFF252B38);
      g.drawString(textRenderer, "67Client", LEFT + 10, TOP + 9, 0xFFFFFFFF, false);
      g.drawString(textRenderer, "Android-compatible menu", LEFT + 82, TOP + 9, 0xFFB9C4D8, false);

      int searchY = TOP + 36;
      int searchRight = panelRight - 10;
      g.fill(CONTENT_X, searchY, searchRight, searchY + 20, 0xFF252B38);
      String queryText = search.isEmpty() && !searchFocused ? "Search modules..." : search + (searchFocused ? "_" : "");
      g.drawString(textRenderer, queryText, CONTENT_X + 7, searchY + 6, search.isEmpty() ? 0xFF8E98AA : 0xFFFFFFFF, false);

      int categoryY = searchY + 30;
      for (Category category : Category.values()) {
         boolean active = category == selectedCategory;
         int y = categoryY + category.ordinal() * 27;
         g.fill(LEFT + 8, y, LEFT + SIDEBAR_W - 5, y + 23, active ? 0xFF3A5F91 : 0xFF252B38);
         g.drawString(textRenderer, category.getDisplayName(), LEFT + 15, y + 7, active ? 0xFFFFFFFF : 0xFFCFD5E0, false);
      }

      int listTop = searchY + 30;
      int listBottom = panelBottom - 10;
      int rowIndex = 0;
      for (int i = scroll; i < visibleModules.size(); i++) {
         int y = listTop + rowIndex * ROW_H;
         if (y + ROW_H > listBottom) break;
         Module module = visibleModules.get(i);
         int rowRight = searchRight;
         g.fill(CONTENT_X, y, rowRight, y + ROW_H - 2, module.isEnabled() ? 0xFF244A3A : 0xFF252B38);
         g.drawString(textRenderer, module.getName(), CONTENT_X + 7, y + 5, module.isEnabled() ? 0xFF7CFFB0 : 0xFFE3E7EF, false);
         String state = module.isEnabled() ? "ON" : "OFF";
         int stateColor = module.isEnabled() ? 0xFF7CFFB0 : 0xFF9AA4B5;
         g.drawString(textRenderer, state, rowRight - 28, y + 5, stateColor, false);
         rowIndex++;
      }

      if (visibleModules.isEmpty()) {
         g.drawString(textRenderer, "No modules found", CONTENT_X + 8, listTop + 8, 0xFFB9C4D8, false);
      }
      g.drawString(textRenderer, "Tap a module to toggle  •  ESC to close", LEFT + 8, panelBottom - 12, 0xFF9AA4B5, false);
      super.render(g, mouseX, mouseY, delta);
   }

   @Override
   public boolean mouseClicked(Click event, boolean doubled) {
      double mx = event.x();
      double my = event.y();
      int button = event.button();
      if (button != 0) return true;

      int searchY = TOP + 36;
      int searchRight = Math.min(width - 12, CONTENT_X + CONTENT_W) - 10;
      if (mx >= CONTENT_X && mx <= searchRight && my >= searchY && my <= searchY + 20) {
         searchFocused = true;
         return true;
      }
      searchFocused = false;

      int categoryY = searchY + 30;
      for (Category category : Category.values()) {
         int y = categoryY + category.ordinal() * 27;
         if (mx >= LEFT + 8 && mx <= LEFT + SIDEBAR_W - 5 && my >= y && my <= y + 23) {
            selectedCategory = category;
            scroll = 0;
            refreshModules();
            UiSounds.select();
            return true;
         }
      }

      int listTop = searchY + 30;
      int rowIndex = (int)((my - listTop) / ROW_H);
      if (mx >= CONTENT_X && mx <= searchRight && rowIndex >= 0) {
         int index = scroll + rowIndex;
         if (index < visibleModules.size()) {
            visibleModules.get(index).toggle();
            UiSounds.select();
         }
      }
      return true;
   }

   @Override
   public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
      scroll -= (int)Math.signum(scrollY) * 3;
      refreshModules();
      return true;
   }

   @Override
   public boolean keyPressed(KeyInput event) {
      if (event.isEscape()) {
         close();
         return true;
      }
      if (searchFocused) {
         if (event.key() == 259 && !search.isEmpty()) {
            search = search.substring(0, search.length() - 1);
            refreshModules();
            return true;
         }
         if (event.key() == 257 || event.key() == 335) {
            searchFocused = false;
            return true;
         }
      }
      return super.keyPressed(event);
   }

   @Override
   public boolean charTyped(CharInput event) {
      if (searchFocused && event.isValidChar() && search.length() < 48) {
         search += event.asString();
         refreshModules();
         return true;
      }
      return super.charTyped(event);
   }

   public void openSearch(String query) {
      search = query == null ? "" : query;
      searchFocused = true;
      refreshModules();
   }

   public ConfigPanel configPanel() { return configPanel; }

   public void openBlockPicker(BlockListSetting setting) {
      BlockGridModel model = new BlockGridModel(setting, () -> {
         BlockEspModule blockEsp = SixSevenClient.modules().blockEsp;
         return blockEsp != null ? blockEsp.lineColor.get() : -16711736;
      }, "Pick Block");
      this.client.setScreen(new IconPickerScreen(this, model, SixSevenClient.themes()));
   }

   public void openIconPicker(IconListSetting setting) {
      IconListGridModel model = new IconListGridModel(setting);
      this.client.setScreen(new IconPickerScreen(this, model, SixSevenClient.themes()));
   }
}
