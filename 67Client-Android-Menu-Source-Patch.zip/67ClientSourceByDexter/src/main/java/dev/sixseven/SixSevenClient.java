package dev.sixseven;

import dev.sixseven.config.ConfigManager;
import dev.sixseven.config.ConfigStore;
import dev.sixseven.gui.ClickGuiScreen;
import dev.sixseven.gui.GambleRiggerOverlay;
import dev.sixseven.hud.HudManager;
import dev.sixseven.license.LicenseGuard;
import dev.sixseven.license.ProtectedContent;
import dev.sixseven.module.Category;
import dev.sixseven.module.ModuleManager;
import dev.sixseven.module.impl.FreecamModule;
import dev.sixseven.notification.NotificationManager;
import dev.sixseven.render.MotionBlurRenderer;
import dev.sixseven.render.OverlayRenderer;
import dev.sixseven.render.SusChunkRenderer;
import dev.sixseven.spotify.SpotifyService;
import dev.sixseven.suschunk.ServerLightCache;
import dev.sixseven.theme.SoundSettings;
import dev.sixseven.theme.ThemeManager;
import dev.sixseven.util.UiSoundEvents;
import dev.sixseven.util.UiSounds;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.ClientStopping;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.StartTick;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Disconnect;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Join;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterInit;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SixSevenClient implements ClientModInitializer {
   public static final String MOD_ID = "sixsevenclient";
   public static final String NAME = "Client";
   public static final String VERSION = "1.6.2";
   public static final Logger LOGGER = LoggerFactory.getLogger("Client");
   private static ModuleManager modules;
   private static ThemeManager themes;
   private static ConfigManager config;
   private static ConfigStore configStore;
   private static HudManager hud;
   private static NotificationManager notifications;
   private static SpotifyService spotify;
   private static SoundSettings soundSettings;
   private static boolean startupSoundPlayed;

   public static ModuleManager modules() {
      return modules;
   }

   public static ThemeManager themes() {
      return themes;
   }

   public static ConfigManager config() {
      return config;
   }

   public static ConfigStore configStore() {
      return configStore;
   }

   public static HudManager hud() {
      return hud;
   }

   public static SpotifyService spotify() {
      return spotify;
   }

   public static SoundSettings sounds() {
      return soundSettings;
   }

   public static NotificationManager notifications() {
      return notifications;
   }

   public void onInitializeClient() {
      byte[] contentKey = LicenseGuard.enforce(LOGGER);
      ProtectedContent.init(contentKey);
      ProtectedContent.activate(LOGGER, "dev.sixseven.secured.SecuredFeature");
      LOGGER.info("{} {} initializing", "Client", "1.6.2");
      UiSoundEvents.bootstrap();
      themes = new ThemeManager();
      soundSettings = new SoundSettings();
      modules = new ModuleManager();
      spotify = new SpotifyService();
      notifications = new NotificationManager(themes, modules.hud);
      hud = new HudManager(modules, themes, spotify, notifications);
      config = new ConfigManager(modules, themes);
      config.addSection("hud", hud::toJson, hud::fromJson);
      config.addSection("panels", ClickGuiScreen.state()::toJson, ClickGuiScreen.state()::fromJson);
      config.addSection("sounds", soundSettings::toJson, soundSettings::fromJson);
      config.load();
      configStore = new ConfigStore(config);
      configStore.loadAll();
      UiSounds.init(soundSettings);
      modules.setOpenGuiAction(() -> MinecraftClient.getInstance().setScreen(new ClickGuiScreen()));
      modules.setToggleListener((module, enabled) -> {
         if (!ConfigStore.applying) {
            if (module.getCategory() != Category.CLIENT) {
               if (MinecraftClient.getInstance().world != null) {
                  if (modules.hud.notifications.get()) {
                     notifications.push(module.getName(), enabled);
                     UiSounds.notification(enabled);
                  }
               }
            }
         }
      });
      OverlayRenderer.init(hud, notifications);
      ScreenEvents.AFTER_INIT.register((AfterInit)(client, screen, scaledWidth, scaledHeight) -> {
         if (screen instanceof TitleScreen && !startupSoundPlayed) {
            startupSoundPlayed = true;
            UiSounds.playStartup();
         }
      });
      GambleRiggerOverlay.register();
      spotify.start();
      ClientPlayConnectionEvents.JOIN.register((Join)(handler, sender, client) -> clearSusState());
      ClientPlayConnectionEvents.DISCONNECT.register((Disconnect)(handler, client) -> clearSusState());
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)client -> modules.onTick());
      ClientTickEvents.START_CLIENT_TICK.register((StartTick)client -> {
         FreecamModule f = modules.freecam;
         if (f != null && f.isActive()) {
            FreecamModule.reapplyBodyInput(client);
         }

         modules.onCombatTick();
      });
      ClientLifecycleEvents.CLIENT_STOPPING.register((ClientStopping)client -> {
         config.save();
         spotify.stop();
      });
   }

   private static void clearSusState() {
      ServerLightCache.get().clear();
      modules.susChunkFinder.scanner.clear();
      SusChunkRenderer.reset();
      if (modules.chunkFinder != null) {
         modules.chunkFinder.clear();
      }

      if (modules.blockEntityEsp != null) {
         modules.blockEntityEsp.clear();
      }

      if (modules.jumpCircles != null) {
         modules.jumpCircles.clear();
      }

      if (modules.hitParticles != null) {
         modules.hitParticles.clear();
      }

      if (modules.customAccessories != null) {
         modules.customAccessories.clear();
      }

      MotionBlurRenderer.reset();
   }
}
